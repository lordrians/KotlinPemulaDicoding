// main function
fun main() {
    10.printInt()
}

fun Int.printInt() {
    print("value $this")
}